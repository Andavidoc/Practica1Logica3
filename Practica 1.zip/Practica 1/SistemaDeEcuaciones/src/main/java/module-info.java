module com.mycompany.sistemadeecuaciones {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.sistemadeecuaciones to javafx.fxml;
    exports com.mycompany.sistemadeecuaciones;
}
