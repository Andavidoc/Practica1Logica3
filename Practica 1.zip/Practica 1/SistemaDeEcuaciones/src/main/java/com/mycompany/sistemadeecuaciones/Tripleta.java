package com.mycompany.sistemadeecuaciones;

public class Tripleta {

    private int fila, columna;
    private Object valor;

    public Tripleta(int f, int c, Object v) {
        this.fila = f;
        this.columna = c;
        this.valor = v;
    }

    public void asignaFila(int f) {
        fila = f;
    }

    public void asignaColumna(int c) {

        columna = c;
    }

    void asignaValor(Object v) {
        valor = v;
    }
     
    public int retornaFila() {
        return fila;
    }

    public int retornaColumna() {

        return columna;
    }

    public Object retornaValor() {

        return valor;
    }   
}
