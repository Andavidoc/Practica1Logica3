package com.mycompany.sistemadeecuaciones;

public class MatrizEnTripletas {

    private Tripleta V[];

    MatrizEnTripletas construyeMatrizEnTripletas(int m, int n) {
        int c, d;
        Tripleta t = new Tripleta(m, n, null);
        MatrizEnTripletas a = new MatrizEnTripletas(t);
        c = 0;
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                d = (int)t.retornaValor();
                if (d != 0) {
                    c = c + 1;
                    t = new Tripleta(i, j, d);
                    a.asignaTripleta(t, c);
                }
            }
        }
        a.asignaNumeroTripletas(c);
        return a;
    }
    
    MatrizEnTripletas(){
    
    }
    
    MatrizEnTripletas(Tripleta t) {
        int m = t.retornaFila();
        int n = t.retornaColumna();
        int p = m * n + 2;
        int i;
        V = new Tripleta[p];
        V[0] = t;
        for (i = 1; i < p; i++) {
            V[i] = null;
        }
    }  

    public void asignaTripleta(Tripleta tx, int i) {
        V[i] = tx;
    }

    public void asignaNumeroTripletas(int n) {
        Tripleta t = V[0];
        t.asignaValor(n);
        V[0] = t;
    }

    public int retornaNumeroFilas() {
        Tripleta t = V[0];
        return t.retornaFila();
    }

    public int retornaNumeroColumnas() {
        Tripleta t = V[0];
        return t.retornaColumna();
    }

    public int retornaNumeroTripletas() {
        Tripleta t = V[0];
        return (int) t.retornaValor();
    }

    public Tripleta retornaTripleta(int i) {
        return V[i];
    }

    public void muestraMatrizEnTripletas() {
        int i = 1;
        Tripleta t = retornaTripleta(0);
        int datos = (int) t.retornaValor();
        
        while (i <= datos) {
           
            System.out.println(V[i].retornaFila() + " " + V[i].retornaColumna() + " " + (int) V[i].retornaValor());

            i = i + 1;
           
            }        
    }

    public void insertaTripleta(Tripleta ti) {
        int i, j, p;
        Tripleta t, tx;
        tx = retornaTripleta(0);
        p = (int) tx.retornaValor();
        i = 1;
        t = retornaTripleta(i);
        while (i <= p && t.retornaFila() < ti.retornaFila()) {
            i = i + 1;
            t = retornaTripleta(i);
        }
        while (i <= p && t.retornaFila() == ti.retornaFila() && t.retornaColumna() < ti.retornaColumna()) {
            i = i + 1;
            t = retornaTripleta(i);
        }
        p = p + 1;
        j = p - 1;
        while (j >= i) {
            V[j + 1] = V[j];
            j = j - 1;
        }
        V[i] = ti;
        asignaNumeroTripletas(p);
    }

    public MatrizEnTripletas suma(MatrizEnTripletas b) {
        int ma, na, mb, nb, p, q, i, j, k, ss, fi, fj, ci, cj, vi, vj;
        Tripleta ti, tj, tx;
        ma = retornaNumeroFilas();
        na = retornaNumeroColumnas();
        mb = b.retornaNumeroFilas();
        nb = b.retornaNumeroColumnas();
        p = retornaNumeroTripletas();
        q = b.retornaNumeroTripletas();
        if ((ma != mb) || (na != nb)) {
            System.out.println("Matrices de diferentes dimensiones no se puede sumar");
            return null;
        }
        ti = new Tripleta(ma, na, 0);
        MatrizEnTripletas c = new MatrizEnTripletas(ti);
        i = 1;
        j = 1;
        k = 0;
        while ((i <= p) && (j <= q)) {
            ti = retornaTripleta(i);
            tj = b.retornaTripleta(j);
            fi = ti.retornaFila();
            fj = tj.retornaFila();
            k = k + 1;

            switch (comparar(fi, fj)) {

                case -1: { // fila de A menor que fila de b 
                    c.asignaTripleta(ti, k);
                    i = i + 1;
                    break;
                }
                case +1: { // fila de A mayor que fila de b 
                    c.asignaTripleta(tj, k);
                    j = j + 1;
                    break;
                }
                case 0: // fila de A igual a fila de b
                    ci = ti.retornaColumna();
                    cj = tj.retornaColumna();
                    switch (comparar(ci, cj)) {
                        case -1: { // columna de A menor que columna de b
                            c.asignaTripleta(ti, k);
                            i = i + 1;
                            break;
                        }
                        case +1: { // columna de A mayor que columna de b
                            c.asignaTripleta(tj, k);
                            j = j + 1;
                            break;
                        }
                        case 0: { // columna de A igual a columna de b
                            vi = (int) ti.retornaValor();
                            vj = (int) tj.retornaValor();
                            ss = vi + vj;
                            if (ss != 0) {
                                tx = new Tripleta(fi, ci, ss);
                                c.asignaTripleta(tx, k);
                            } else {
                                k = k - 1;
                            }
                            i = i + 1;
                            j = j + 1;
                            break;
                        }
                    }
            }
        }
        while (i <= p) {
            ti = retornaTripleta(i);
            k = k + 1;
            c.asignaTripleta(ti, k);
            i = i + 1;
        }
        while (j <= q) {
            tj = b.retornaTripleta(j);
            k = k + 1;
            c.asignaTripleta(tj, k);
            j = j + 1;
        }
        c.asignaNumeroTripletas(k);
        return c;
    }

    public int comparar(int d1, int d2) {
        if (d1 < d2) {
            return -1;
        }
        if (d1 == d2) {
            return 0;
        }
        return +1;
    }

    public MatrizEnTripletas traspuesta() {
        int i, p, f, c, v;
        Tripleta ti;
        p = retornaNumeroTripletas();
        ti = new Tripleta(retornaNumeroColumnas(), retornaNumeroFilas(), 0);
        MatrizEnTripletas b = new MatrizEnTripletas(ti);
        i = 1;
        while (i <= p) {
            ti = retornaTripleta(i);
            f = ti.retornaColumna();
            c = ti.retornaFila();
            v = (int) ti.retornaValor();
            ti = new Tripleta(f, c, v);
            b.insertaTripleta(ti);
            i = i + 1;
        }
        return b;
    }

    MatrizEnTripletas traspuestaMedia() {
        int i, j, k, m, n, p, f, c, v;
        Tripleta tj, tx;
        m = retornaNumeroFilas();
        n = retornaNumeroColumnas();
        p = retornaNumeroTripletas();
        tx = new Tripleta(n, m, p);
        MatrizEnTripletas b = new MatrizEnTripletas(tx);
        k = 0;
        for (i = 1; i <= n; i++) {
            for (j = 1; j <= p; j++) {
                tj = retornaTripleta(j);
                f = tj.retornaFila();
                c = tj.retornaColumna();
                v = (int) tj.retornaValor();
                if (c == i) {
                    k = k + 1;
                    tx = new Tripleta(c, f, v);
                    b.asignaTripleta(tx, k);
                }
            }
        }
        return b;
    }

    public MatrizEnTripletas traspuestaRapida() {
        int m, n, p, i, j, s[], t[];
        Tripleta ti, tx;
        m = retornaNumeroFilas();
        n = retornaNumeroColumnas();
        p = retornaNumeroTripletas();
        ti = new Tripleta(n, m, p);
        MatrizEnTripletas b = new MatrizEnTripletas(ti);
        s = new int[n + 1];
        t = new int[n + 1];
        for (i = 1; i <= n; i++) {
            s[i] = 0;
        }
        for (i = 1; i <= p; i++) {
            ti = retornaTripleta(i);
            s[ti.retornaColumna()] = s[ti.retornaColumna()] + 1;
        }
        t[1] = 1;
        for (i = 2; i <= n; i++) {
            t[i] = t[i - 1] + s[i - 1];
        }
        for (i = 1; i <= p; i++) {
            ti = retornaTripleta(i);
            j = ti.retornaColumna();
            tx = new Tripleta(j, ti.retornaFila(), (int) ti.retornaValor());
            b.asignaTripleta(tx, t[j]);
            t[j] = t[j] + 1;
        }
        return b;
    }
}
