package com.mycompany.sistemadeecuaciones;

public class nodoDoble {

    private Tripleta dato;
    private nodoDoble ligaI, ligaD;

    public nodoDoble() {

    }

    nodoDoble(Tripleta t) {
        dato = t;
        ligaD = null;
        ligaI = null;
    }

    void asignaDato(Tripleta t) {
        dato = t;
    }
    
    
    
     Tripleta retornaDato() {
        return dato;
    }

    nodoDoble retornaLd() {
        return ligaD;
    }

    void asignaLd(nodoDoble x) {
        ligaD = x;
    }

    void asignaLi(nodoDoble x) {
        ligaI = x;
    }

    nodoDoble retornaLi() {
          return ligaI;
    }

}
