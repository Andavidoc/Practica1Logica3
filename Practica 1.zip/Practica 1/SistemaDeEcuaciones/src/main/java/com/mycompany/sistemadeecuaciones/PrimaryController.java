package com.mycompany.sistemadeecuaciones;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

public class PrimaryController {

    @FXML
    private Button primaryButton1;
    @FXML
    private Button primaryButton2;
    @FXML
    private Button primaryButton21;
    @FXML
    private TextField x1;
    @FXML
    private TextField y1;
    @FXML
    private TextField z1;
    @FXML
    private TextField r1;
    @FXML
    private TextField x2;
    @FXML
    private TextField y2;
    @FXML
    private TextField z2;
    @FXML
    private TextField r2;
    @FXML
    private TextField x3;
    @FXML
    private TextField y3;
    @FXML
    private TextField z3;
    @FXML
    private TextField r3;
    @FXML
    private TextArea respuesta;
    @FXML
    private Label labError;

    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary");
    }

    private void suma() {
        int j = Integer.parseInt(x1.getText());
        int m = Integer.parseInt(x2.getText());
        int r = j + m;
        respuesta.setText(r + "");
    }
// Metodo de cramer
    @FXML
    private void Cramer(ActionEvent event) {
    // Se verifica que todos los valores ingresados sean numericos 
        prueba1();
        prueba2();
        prueba3();
        prueba4();
        prueba5();
        prueba6();
        prueba7();
        prueba8();
        prueba9();
        prueba10();
        prueba11();
        prueba12();
    // Si todos los valores dan true, entonces se procede con el metodo    
        if (prueba1() != false && prueba2() != false && prueba3() != false && prueba4() != false
                && prueba5() != false && prueba6() != false && prueba7() != false && prueba8() != false
                && prueba9() != false && prueba12() != false && prueba11() != false && prueba12() != false) {
    // Se crea la matriz incial en tripletas y se añade a la matriz en tripletas        
            Tripleta inicial = new Tripleta(3, 4, 12);
            Tripleta xuno = new Tripleta(1, 1, Integer.parseInt(x1.getText()));
            Tripleta yuno = new Tripleta(1, 2, Integer.parseInt(y1.getText()));
            Tripleta zuno = new Tripleta(1, 3, Integer.parseInt(z1.getText()));
            Tripleta runo = new Tripleta(1, 4, Integer.parseInt(r1.getText()));
            Tripleta xdos = new Tripleta(2, 1, Integer.parseInt(x2.getText()));
            Tripleta ydos = new Tripleta(2, 2, Integer.parseInt(y2.getText()));
            Tripleta zdos = new Tripleta(2, 3, Integer.parseInt(z2.getText()));
            Tripleta rdos = new Tripleta(2, 4, Integer.parseInt(r2.getText()));
            Tripleta xtres = new Tripleta(3, 1, Integer.parseInt(x3.getText()));
            Tripleta ytres = new Tripleta(3, 2, Integer.parseInt(y3.getText()));
            Tripleta ztres = new Tripleta(3, 3, Integer.parseInt(z3.getText()));
            Tripleta rtres = new Tripleta(3, 4, Integer.parseInt(r3.getText()));
            
//Se asignan las tripletas a la matriz
            MatrizEnTripletas prueba = new MatrizEnTripletas(inicial);
            prueba.asignaTripleta(xuno, 1);
            prueba.asignaTripleta(yuno, 2);
            prueba.asignaTripleta(zuno, 3);
            prueba.asignaTripleta(runo, 4);
            prueba.asignaTripleta(xdos, 5);
            prueba.asignaTripleta(ydos, 6);
            prueba.asignaTripleta(zdos, 7);
            prueba.asignaTripleta(rdos, 8);
            prueba.asignaTripleta(xtres, 9);
            prueba.asignaTripleta(ytres, 10);
            prueba.asignaTripleta(ztres, 11);
            prueba.asignaTripleta(rtres, 12);
            
            // Se extraen  los numeros de la matriz para verificar su determinante
            double xu = (int) xuno.retornaValor();
            double yu = (int) yuno.retornaValor();
            double zu = (int) zuno.retornaValor();
            double xd = (int) xdos.retornaValor();
            double yd = (int) ydos.retornaValor();
            double zd = (int) zdos.retornaValor();
            double xt = (int) xtres.retornaValor();
            double yt = (int) ytres.retornaValor();
            double zt = (int) ztres.retornaValor();
            double ru = (int) runo.retornaValor();
            double rd = (int) rdos.retornaValor();
            double rt = (int) rtres.retornaValor();
            
            double dets = (xu * yd * zt + xd * yt * zu + xt * yu * zd) - (zu * yd * xt + zd * yt * xu + zt * yu * xd);
            double detx = (ru * yd * zt + rd * yt * zu + rt * yu * zd) - (zu * yd * rt + zd * yt * ru + zt * yu * rd);
            double dety = (xu * rd * zt + xd * rt * zu + xt * ru * zd) - (zu * rd * xt + zd * rt * xu + zt * ru * xd);
            double detz = (xu * yd * rt + xd * yt * ru + xt * yu * rd) - (ru * yd * xt + rd * yt * xu + rt * yu * xd);
            
            if (dets == 0) {
                respuesta.setText("El determinate del sistema de la matriz no puede ser 0");
                
                // se generan los valores de x,y,z y se imprimen en pantalla
            } else {
                double x = detx / dets;
                double y = dety / dets;
                double z = detz / dets;
                
                respuesta.setText(inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n"
                        + "Δs:" + dets + "\nΔx: " + detx + "\nΔy:" + dety + "\nΔz:" + detz
                        + "\nX=Δx/Δs =" + detx + "/" + dets + "= " + x
                        + "\nY=Δy/Δs =" + dety + "/" + dets + "= " + y
                        + "\nZ=Δz/Δs =" + detz + "/" + dets + "= " + z
                );
            }
        }
    }

    double xu, yu, zu, ru, xd, yd, zd, rd, xt, yt, zt, rt;

    @FXML
    // Gauss Jordan.
    private void gauss(ActionEvent event) {
    // Se verifica que todos los valores ingresados sean numericos 
        prueba1();
        prueba2();
        prueba3();
        prueba4();
        prueba5();
        prueba6();
        prueba7();
        prueba8();
        prueba9();
        prueba10();
        prueba11();
        prueba12();
        
    // Si todos los valores dan true, entonces se procede con el metodo    

        if (prueba1() != false && prueba2() != false && prueba3() != false && prueba4() != false
                && prueba5() != false && prueba6() != false && prueba7() != false && prueba8() != false
                && prueba9() != false && prueba12() != false && prueba11() != false && prueba12() != false){

            double po = 0;
            double ne = 0;
            Tripleta inicial = new Tripleta(3, 4, 12);
            Tripleta xuno = new Tripleta(1, 1, Integer.parseInt(x1.getText()));
            Tripleta yuno = new Tripleta(1, 2, Integer.parseInt(y1.getText()));
            Tripleta zuno = new Tripleta(1, 3, Integer.parseInt(z1.getText()));
            Tripleta runo = new Tripleta(1, 4, Integer.parseInt(r1.getText()));
            Tripleta xdos = new Tripleta(2, 1, Integer.parseInt(x2.getText()));
            Tripleta ydos = new Tripleta(2, 2, Integer.parseInt(y2.getText()));
            Tripleta zdos = new Tripleta(2, 3, Integer.parseInt(z2.getText()));
            Tripleta rdos = new Tripleta(2, 4, Integer.parseInt(r2.getText()));
            Tripleta xtres = new Tripleta(3, 1, Integer.parseInt(x3.getText()));
            Tripleta ytres = new Tripleta(3, 2, Integer.parseInt(y3.getText()));
            Tripleta ztres = new Tripleta(3, 3, Integer.parseInt(z3.getText()));
            Tripleta rtres = new Tripleta(3, 4, Integer.parseInt(r3.getText()));

            MatrizEnTripletas prueba = new MatrizEnTripletas(inicial);

            prueba.asignaTripleta(xuno, 1);
            prueba.asignaTripleta(yuno, 2);
            prueba.asignaTripleta(zuno, 3);
            prueba.asignaTripleta(runo, 4);
            prueba.asignaTripleta(xdos, 5);
            prueba.asignaTripleta(ydos, 6);
            prueba.asignaTripleta(zdos, 7);
            prueba.asignaTripleta(rdos, 8);
            prueba.asignaTripleta(xtres, 9);
            prueba.asignaTripleta(ytres, 10);
            prueba.asignaTripleta(ztres, 11);
            prueba.asignaTripleta(rtres, 12);

            xu = (int) xuno.retornaValor();
            yu = (int) yuno.retornaValor();
            zu = (int) zuno.retornaValor();
            xd = (int) xdos.retornaValor();
            yd = (int) ydos.retornaValor();
            zd = (int) zdos.retornaValor();
            xt = (int) xtres.retornaValor();
            yt = (int) ytres.retornaValor();
            zt = (int) ztres.retornaValor();
            ru = (int) runo.retornaValor();
            rd = (int) rdos.retornaValor();
            rt = (int) rtres.retornaValor();

            respuesta.setText(inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                    + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                    + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                    + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                    + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                    + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                    + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                    + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                    + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                    + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                    + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                    + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                    + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n"
            );
            // Se concatena la respuesta para que no se pierda informacion en la proxima impresión
            String concat = respuesta.getText();
            
            // Metodos para verificar y cambiar las filas
            if (xu == 0 && xt != 0 && (zu == 0 && zd != 0 && yu != 0)) {
                xuno = new Tripleta(1, 1, (int) xt);
                yuno = new Tripleta(1, 2, (int) yt);
                zuno = new Tripleta(1, 3, (int) zt);
                runo = new Tripleta(1, 4, (int) rt);
                xdos = new Tripleta(2, 1, (int) xu);
                ydos = new Tripleta(2, 2, (int) yu);
                zdos = new Tripleta(2, 3, (int) zu);
                rdos = new Tripleta(2, 4, (int) ru);
                xtres = new Tripleta(3, 1, (int) xd);
                ytres = new Tripleta(3, 2, (int) yd);
                ztres = new Tripleta(3, 3, (int) zd);
                rtres = new Tripleta(3, 4, (int) rd);
                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);
                //baja
                respuesta.setText(concat + "Se intercambia F2 con F1, y luego F1 con F3 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();

            }

            if (xu == 0 && xd != 0 && (yu == 0 && yt != 0 && zu != 0)) {
                xuno = new Tripleta(1, 1, (int) xd);
                yuno = new Tripleta(1, 2, (int) yd);
                zuno = new Tripleta(1, 3, (int) zd);
                runo = new Tripleta(1, 4, (int) rd);
                xdos = new Tripleta(2, 1, (int) xt);
                ydos = new Tripleta(2, 2, (int) yt);
                zdos = new Tripleta(2, 3, (int) zt);
                rdos = new Tripleta(2, 4, (int) rt);
                xtres = new Tripleta(3, 1, (int) xu);
                ytres = new Tripleta(3, 2, (int) yu);
                ztres = new Tripleta(3, 3, (int) zu);
                rtres = new Tripleta(3, 4, (int) ru);
                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);
                //sube
                respuesta.setText(concat + "Se intercambia F2 con F1, y luego F2 con F3 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();

            }
            if (yd == 0 && yt != 0 && (zd == 0 && zu != 0 && xd != 0)) {
                xuno = new Tripleta(1, 1, (int) xd);
                yuno = new Tripleta(1, 2, (int) yd);
                zuno = new Tripleta(1, 3, (int) zd);
                runo = new Tripleta(1, 4, (int) rd);
                xdos = new Tripleta(2, 1, (int) xt);
                ydos = new Tripleta(2, 2, (int) yt);
                zdos = new Tripleta(2, 3, (int) zt);
                rdos = new Tripleta(2, 4, (int) rt);
                xtres = new Tripleta(3, 1, (int) xu);
                ytres = new Tripleta(3, 2, (int) yu);
                ztres = new Tripleta(3, 3, (int) zu);
                rtres = new Tripleta(3, 4, (int) ru);
                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);
                //sube
                respuesta.setText(concat + "Se intercambia F2 con F1, y luego F2 con F3 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();

            }

            if (yd == 0 && yu != 0 && (xd == 0 && xt != 0 && zd != 0)) {
                xuno = new Tripleta(1, 1, (int) xt);
                yuno = new Tripleta(1, 2, (int) yt);
                zuno = new Tripleta(1, 3, (int) zt);
                runo = new Tripleta(1, 4, (int) rt);
                xdos = new Tripleta(2, 1, (int) xu);
                ydos = new Tripleta(2, 2, (int) yu);
                zdos = new Tripleta(2, 3, (int) zu);
                rdos = new Tripleta(2, 4, (int) ru);
                xtres = new Tripleta(3, 1, (int) xd);
                ytres = new Tripleta(3, 2, (int) yd);
                ztres = new Tripleta(3, 3, (int) zd);
                rtres = new Tripleta(3, 4, (int) rd);
                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);
                //baja
                respuesta.setText(concat + "Se intercambia F2 con F1, y luego F1 con F3 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();

            }
            if (zt == 0 && zd != 0 && (yt == 0 && yu != 0 && xt != 0)) {
                xuno = new Tripleta(1, 1, (int) xt);
                yuno = new Tripleta(1, 2, (int) yt);
                zuno = new Tripleta(1, 3, (int) zt);
                runo = new Tripleta(1, 4, (int) rt);
                xdos = new Tripleta(2, 1, (int) xu);
                ydos = new Tripleta(2, 2, (int) yu);
                zdos = new Tripleta(2, 3, (int) zu);
                rdos = new Tripleta(2, 4, (int) ru);
                xtres = new Tripleta(3, 1, (int) xd);
                ytres = new Tripleta(3, 2, (int) yd);
                ztres = new Tripleta(3, 3, (int) zd);
                rtres = new Tripleta(3, 4, (int) rd);
                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);
                //baja
                respuesta.setText(concat + "Se intercambia F2 con F1, y luego F1 con F3 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();

            }
            if (zt == 0 && zu != 0 && (xt == 0 && xd != 0 && yt != 0)) {
                xuno = new Tripleta(1, 1, (int) xd);
                yuno = new Tripleta(1, 2, (int) yd);
                zuno = new Tripleta(1, 3, (int) zd);
                runo = new Tripleta(1, 4, (int) rd);
                xdos = new Tripleta(2, 1, (int) xt);
                ydos = new Tripleta(2, 2, (int) yt);
                zdos = new Tripleta(2, 3, (int) zt);
                rdos = new Tripleta(2, 4, (int) rt);
                xtres = new Tripleta(3, 1, (int) xu);
                ytres = new Tripleta(3, 2, (int) yu);
                ztres = new Tripleta(3, 3, (int) zu);
                rtres = new Tripleta(3, 4, (int) ru);
                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);
                //sube
                respuesta.setText(concat + "Se intercambia F2 con F1, y luego F2 con F3 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();

            }

            if (xu == 0 && xd != 0 && yu != 0) {
                xuno = new Tripleta(1, 1, (int) xd);
                yuno = new Tripleta(1, 2, (int) yd);
                zuno = new Tripleta(1, 3, (int) zd);
                runo = new Tripleta(1, 4, (int) rd);
                xdos = new Tripleta(2, 1, (int) xu);
                ydos = new Tripleta(2, 2, (int) yu);
                zdos = new Tripleta(2, 3, (int) zu);
                rdos = new Tripleta(2, 4, (int) ru);
                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);

                respuesta.setText(concat + "Se Intercambia F1 con F2 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();

                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();
            }

            if (xu == 0 && xt != 0 && zu != 0) {
                xuno = new Tripleta(1, 1, (int) xt);
                yuno = new Tripleta(1, 2, (int) yt);
                zuno = new Tripleta(1, 3, (int) zt);
                runo = new Tripleta(1, 4, (int) rt);
                xtres = new Tripleta(3, 1, (int) xu);
                ytres = new Tripleta(3, 2, (int) yu);
                ztres = new Tripleta(3, 3, (int) zu);
                rtres = new Tripleta(3, 4, (int) ru);
                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);

                

                respuesta.setText(concat + "Se Intercambia F1 con F3 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();

                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();

            }

            if (yd == 0 && yu != 0 && xd != 0) {
                xuno = new Tripleta(1, 1, (int) xd);
                yuno = new Tripleta(1, 2, (int) yd);
                zuno = new Tripleta(1, 3, (int) zd);
                runo = new Tripleta(1, 4, (int) rd);
                xdos = new Tripleta(2, 1, (int) xu);
                ydos = new Tripleta(2, 2, (int) yu);
                zdos = new Tripleta(2, 3, (int) zu);
                rdos = new Tripleta(2, 4, (int) ru);
                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);

                respuesta.setText(concat + "Se Intercambia F2 con F1 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();
            }
            if (yd == 0 && yt != 0 && zd != 0) {
                xdos = new Tripleta(2, 1, (int) xt);
                ydos = new Tripleta(2, 2, (int) yt);
                zdos = new Tripleta(2, 3, (int) zt);
                rdos = new Tripleta(2, 4, (int) rt);
                xtres = new Tripleta(3, 1, (int) xd);
                ytres = new Tripleta(3, 2, (int) yd);
                ztres = new Tripleta(3, 3, (int) zd);
                rtres = new Tripleta(3, 4, (int) rd);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);

                respuesta.setText(concat + "Se Intercambia F2 con F3 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();
            }
            if (zt == 0 && zu != 0 && xt != 0) {
                xuno = new Tripleta(1, 1, (int) xt);
                yuno = new Tripleta(1, 2, (int) yt);
                zuno = new Tripleta(1, 3, (int) zt);
                runo = new Tripleta(1, 4, (int) rt);
                xtres = new Tripleta(3, 1, (int) xu);
                ytres = new Tripleta(3, 2, (int) yu);
                ztres = new Tripleta(3, 3, (int) zu);
                rtres = new Tripleta(3, 4, (int) ru);
                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);

                respuesta.setText(concat + "Se Intercambia F3 con F1 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();
            }

            if (zt == 0 && zd != 0 && xt != 0) {
                xdos = new Tripleta(2, 1, (int) xt);
                ydos = new Tripleta(2, 2, (int) yt);
                zdos = new Tripleta(2, 3, (int) zt);
                rdos = new Tripleta(2, 4, (int) rt);
                xtres = new Tripleta(3, 1, (int) xd);
                ytres = new Tripleta(3, 2, (int) yd);
                ztres = new Tripleta(3, 3, (int) zd);
                rtres = new Tripleta(3, 4, (int) rd);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);

                respuesta.setText(concat + "Se Intercambia F3 con F2 \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
                xu = (int) xuno.retornaValor();
                yu = (int) yuno.retornaValor();
                zu = (int) zuno.retornaValor();
                xd = (int) xdos.retornaValor();
                yd = (int) ydos.retornaValor();
                zd = (int) zdos.retornaValor();
                xt = (int) xtres.retornaValor();
                yt = (int) ytres.retornaValor();
                zt = (int) ztres.retornaValor();
                ru = (int) runo.retornaValor();
                rd = (int) rdos.retornaValor();
                rt = (int) rtres.retornaValor();
            }

            // condicionales para dejar las columnas con su respectivo pivotes
            if (xu != 0 && xd != 0) {
                po = xd;
                ne = -xu;
                xu = xu * po;
                yu = yu * po;
                zu = zu * po;
                ru = ru * po;

                xd = xd * ne;
                yd = yd * ne;
                zd = zd * ne;
                rd = rd * ne;

                xd = xd + xu;
                yd = yd + yu;
                zd = zd + zu;
                rd = rd + ru;
            // se vuelven a guardar las tripletas con los valores nuevos a la matriz
                xuno = new Tripleta(1, 1, xu);
                yuno = new Tripleta(1, 2, yu);
                zuno = new Tripleta(1, 3, zu);
                runo = new Tripleta(1, 4, ru);
                xdos = new Tripleta(2, 1, xd);
                ydos = new Tripleta(2, 2, yd);
                zdos = new Tripleta(2, 3, zd);
                rdos = new Tripleta(2, 4, rd);
                xtres = new Tripleta(3, 1, xt);
                ytres = new Tripleta(3, 2, yt);
                ztres = new Tripleta(3, 3, zt);
                rtres = new Tripleta(3, 4, rt);

                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);

                respuesta.setText(concat + "F2=(" + po + "F1) + (" + ne + "F2)\n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
            }
            if (xu != 0 && xt != 0) {
                po = xt;
                ne = -xu;
                xu = xu * po;
                yu = yu * po;
                zu = zu * po;
                ru = ru * po;

                xt = xt * ne;
                yt = yt * ne;
                zt = zt * ne;
                rt = rt * ne;

                xt = xt + xu;
                yt = yt + yu;
                zt = zt + zu;
                rt = rt + ru;

                xuno = new Tripleta(1, 1, xu);
                yuno = new Tripleta(1, 2, yu);
                zuno = new Tripleta(1, 3, zu);
                runo = new Tripleta(1, 4, ru);
                xdos = new Tripleta(2, 1, xd);
                ydos = new Tripleta(2, 2, yd);
                zdos = new Tripleta(2, 3, zd);
                rdos = new Tripleta(2, 4, rd);
                xtres = new Tripleta(3, 1, xt);
                ytres = new Tripleta(3, 2, yt);
                ztres = new Tripleta(3, 3, zt);
                rtres = new Tripleta(3, 4, rt);

                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);

                respuesta.setText(concat + "F3=(" + po + "F1) + (" + ne + "F3)\n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
            }
            if (yd != 0 && yu != 0) {
                po = yu;
                ne = -yd;
                xu = xu * ne;
                yu = yu * ne;
                zu = zu * ne;
                ru = ru * ne;

                xd = xd * po;
                yd = yd * po;
                zd = zd * po;
                rd = rd * po;

                xu = xu + xd;
                yu = yu + yd;
                zu = zu + zd;
                ru = ru + rd;

                xuno = new Tripleta(1, 1, xu);
                yuno = new Tripleta(1, 2, yu);
                zuno = new Tripleta(1, 3, zu);
                runo = new Tripleta(1, 4, ru);
                xdos = new Tripleta(2, 1, xd);
                ydos = new Tripleta(2, 2, yd);
                zdos = new Tripleta(2, 3, zd);
                rdos = new Tripleta(2, 4, rd);
                xtres = new Tripleta(3, 1, xt);
                ytres = new Tripleta(3, 2, yt);
                ztres = new Tripleta(3, 3, zt);
                rtres = new Tripleta(3, 4, rt);

                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);

                respuesta.setText(concat + "F1=(" + po + "F2) + (" + ne + "F1)\n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
            }
            if (yd != 0 && yt != 0) {
                po = yt;
                ne = -yd;
                xt = xt * ne;
                yt = yt * ne;
                zt = zt * ne;
                rt = rt * ne;

                xd = xd * po;
                yd = yd * po;
                zd = zd * po;
                rd = rd * po;

                xt = xt + xd;
                yt = yt + yd;
                zt = zt + zd;
                rt = rt + rd;

                xuno = new Tripleta(1, 1, xu);
                yuno = new Tripleta(1, 2, yu);
                zuno = new Tripleta(1, 3, zu);
                runo = new Tripleta(1, 4, ru);
                xdos = new Tripleta(2, 1, xd);
                ydos = new Tripleta(2, 2, yd);
                zdos = new Tripleta(2, 3, zd);
                rdos = new Tripleta(2, 4, rd);
                xtres = new Tripleta(3, 1, xt);
                ytres = new Tripleta(3, 2, yt);
                ztres = new Tripleta(3, 3, zt);
                rtres = new Tripleta(3, 4, rt);

                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);

                respuesta.setText(concat + "F3=(" + po + "F2) + (" + ne + "F3)\n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
            }
            if (zt != 0 && zu != 0) {
                po = zu;
                ne = -zt;
                xt = xt * po;
                yt = yt * po;
                zt = zt * po;
                rt = rt * po;

                xu = xu * ne;
                yu = yu * ne;
                zu = zu * ne;
                ru = ru * ne;

                xu = xu + xt;
                yu = yu + yt;
                zu = zu + zt;
                ru = ru + rt;

                xuno = new Tripleta(1, 1, xu);
                yuno = new Tripleta(1, 2, yu);
                zuno = new Tripleta(1, 3, zu);
                runo = new Tripleta(1, 4, ru);
                xdos = new Tripleta(2, 1, xd);
                ydos = new Tripleta(2, 2, yd);
                zdos = new Tripleta(2, 3, zd);
                rdos = new Tripleta(2, 4, rd);
                xtres = new Tripleta(3, 1, xt);
                ytres = new Tripleta(3, 2, yt);
                ztres = new Tripleta(3, 3, zt);
                rtres = new Tripleta(3, 4, rt);

                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);

                respuesta.setText(concat + "F1=(" + po + "F3) + (" + ne + "F1) \n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
            }
            if (zt != 0 && zd != 0) {
                po = zd;
                ne = -zt;
                xt = xt * po;
                yt = yt * po;
                zt = zt * po;
                rt = rt * po;

                xd = xd * ne;
                yd = yd * ne;
                zd = zd * ne;
                rd = rd * ne;

                xd = xd + xt;
                yd = yd + yt;
                zd = zd + zt;
                rd = rd + rt;

                xuno = new Tripleta(1, 1, xu);
                yuno = new Tripleta(1, 2, yu);
                zuno = new Tripleta(1, 3, zu);
                runo = new Tripleta(1, 4, ru);
                xdos = new Tripleta(2, 1, xd);
                ydos = new Tripleta(2, 2, yd);
                zdos = new Tripleta(2, 3, zd);
                rdos = new Tripleta(2, 4, rd);
                xtres = new Tripleta(3, 1, xt);
                ytres = new Tripleta(3, 2, yt);
                ztres = new Tripleta(3, 3, zt);
                rtres = new Tripleta(3, 4, rt);

                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);

                respuesta.setText(concat + "F2=(" + po + "F3) + (" + ne + "F2)\n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n");

                concat = respuesta.getText();
            }
            double x = xu;
            double y = yd;
            double z = zt;
            // Se genera el numero divisor para dejar los pivotes en 1
            if (x != 0 && y != 0 && z != 0) {

                xu = xu / x;
                ru = ru / x;

                yd = yd / y;
                rd = rd / y;

                zt = zt / z;
                rt = rt / z;
                
                xuno = new Tripleta(1, 1, xu);
                yuno = new Tripleta(1, 2, yu);
                zuno = new Tripleta(1, 3, zu);
                runo = new Tripleta(1, 4, ru);
                xdos = new Tripleta(2, 1, xd);
                ydos = new Tripleta(2, 2, yd);
                zdos = new Tripleta(2, 3, zd);
                rdos = new Tripleta(2, 4, rd);
                xtres = new Tripleta(3, 1, xt);
                ytres = new Tripleta(3, 2, yt);
                ztres = new Tripleta(3, 3, zt);
                rtres = new Tripleta(3, 4, rt);

                prueba.asignaTripleta(xuno, 1);
                prueba.asignaTripleta(yuno, 2);
                prueba.asignaTripleta(zuno, 3);
                prueba.asignaTripleta(runo, 4);
                prueba.asignaTripleta(xdos, 5);
                prueba.asignaTripleta(ydos, 6);
                prueba.asignaTripleta(zdos, 7);
                prueba.asignaTripleta(rdos, 8);
                prueba.asignaTripleta(xtres, 9);
                prueba.asignaTripleta(ytres, 10);
                prueba.asignaTripleta(ztres, 11);
                prueba.asignaTripleta(rtres, 12);
                // Se genera la respuesta con sus respectivos valores para cada variable y todo el procedimiento
                respuesta.setText(concat + "F1/" + x + "\n F2/" + y + "\n F3/" + z + "\n" + inicial.retornaFila() + "|" + inicial.retornaColumna() + "|" + inicial.retornaValor() + "\n"
                        + xuno.retornaFila() + "|" + xuno.retornaColumna() + "|" + xuno.retornaValor() + "\n"
                        + yuno.retornaFila() + "|" + yuno.retornaColumna() + "|" + yuno.retornaValor() + "\n"
                        + zuno.retornaFila() + "|" + zuno.retornaColumna() + "|" + zuno.retornaValor() + "\n"
                        + runo.retornaFila() + "|" + runo.retornaColumna() + "|" + runo.retornaValor() + "\n"
                        + xdos.retornaFila() + "|" + xdos.retornaColumna() + "|" + xdos.retornaValor() + "\n"
                        + ydos.retornaFila() + "|" + ydos.retornaColumna() + "|" + ydos.retornaValor() + "\n"
                        + zdos.retornaFila() + "|" + zdos.retornaColumna() + "|" + zdos.retornaValor() + "\n"
                        + rdos.retornaFila() + "|" + rdos.retornaColumna() + "|" + rdos.retornaValor() + "\n"
                        + xtres.retornaFila() + "|" + xtres.retornaColumna() + "|" + xtres.retornaValor() + "\n"
                        + ytres.retornaFila() + "|" + ytres.retornaColumna() + "|" + ytres.retornaValor() + "\n"
                        + ztres.retornaFila() + "|" + ztres.retornaColumna() + "|" + ztres.retornaValor() + "\n"
                        + rtres.retornaFila() + "|" + rtres.retornaColumna() + "|" + rtres.retornaValor() + "\n"
                        + xu + "X = " + ru + "\n" + yd + "Y = " + rd + "\n" + zt + "Z = " + rt + "\n");

                concat = respuesta.getText();
            } else {
                respuesta.setText(concat + "El sistema de ecuaciones no tiene Solución.");
            }
            if ((xu == 0 && ru == 0) || (yd == 0 && rd == 0) || (zt == 0 && rt == 0)) {
                respuesta.setText(concat + "El sistema de ecuaciones tiene infinitas soluciones.");
            }
            
            
        }
    }

    @FXML
    private boolean soloNumeros(KeyEvent event) {
        String solonumero = x2.getText();
        try {
            double prueba = Double.parseDouble(solonumero);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            x2.clear();
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            return false;
        }
    }

    // Metodos para comprobar las casillas 
    public boolean prueba1() {
        String str = x1.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            x1.clear();
            return false;
        }
    }

    public boolean prueba2() {
        String str = y1.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            y1.clear();
            return false;
        }

    }

    public boolean prueba3() {
        String str = z1.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            z1.clear();
            return false;
        }

    }

    public boolean prueba4() {
        String str = r1.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            r1.clear();
            return false;
        }

    }

    public boolean prueba5() {
        String str = x2.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            x2.clear();
            return false;
        }

    }

    public boolean prueba6() {
        String str = y2.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            y2.clear();
            return false;
        }

    }

    public boolean prueba7() {
        String str = z2.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            z2.clear();
            return false;
        }

    }

    public boolean prueba8() {
        String str = r2.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            r2.clear();
            return false;
        }

    }

    public boolean prueba9() {
        String str = x3.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            x3.clear();
            return false;
        }

    }

    public boolean prueba10() {
        String str = y3.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            y3.clear();
            return false;
        }

    }

    public boolean prueba11() {
        String str = z3.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            z3.clear();
            return false;
        }

    }

    public boolean prueba12() {
        String str = r3.getText();
        try {
            Double.parseDouble(str);
            labError.setText("");
            return true;
        } catch (NumberFormatException e) {
            labError.setText("Las casillas no pueden quedar vacías y solo pueden contener números");
            r3.clear();
            return false;
        }

    }

    @FXML
    private void errores(KeyEvent event) {
    }

}
